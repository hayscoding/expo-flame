
const image = new Image();
image.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAACACAIAAAA04/g9AAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6AAAdTAAAOpgAAA6lwAAF2+XqZnUAAAel0lEQVR4nGLkYmX4/5/hHyMDw38GBijB8P8fiAUkGP+DRP4yDF4AEEAsTEwgDzAxMPyDuR5EMYIQI5j/Dyz7Hy47yABAADFzszEwMoJYTIwghwL9A3I6I5T8z8jADHY6EwPUG4MNAAQQCzMzKKSZ/4FCGpiQIKH/H8z4+w/kaEawgn9/QVE0CAFAADHzs4PDnomBkQnkUFDQMzJAcgQoHpjAqsARAo4bUIQwDKaoAAggZmFecB74D3Y3I8gzkBTFwAB1MYgHFoGIQ3P5gDgWGwAIIBZmoKNZQA4CJpK//0EFDiM4rQBD+g84X/+H+IeZ4d8/kPeAJMM/aMQMhpwNEEDMkvwMzEyIsGcCOxeYMf6DszXQe//BbmSE62CCpjEIGHAPAAQQs6QgzOlM0FQEdD0izfwHiUPSPeN/aEnEyADN0P/haWzgAEAAsXAwgZLNP3AKAaYZIAksfBjBwf/3L0gKJMjMwPwX5Pp/YP8ASRZwBQfxyj8GBsaBiwqAAGJhYwElEqCj/4Ad/Qdc8ANLJCZwigeRfxl+/2VgZAFVyIx/QVniD7BUBVd/jOAcwvR/IKtqgABiYWMF587/oDAGZmIWYAyA3fQbmKJ+gctWsH/+/AVVCMDABrqeGVzBAf3GCM7T/8El7H+klgg9AUAAsbAzM/xlArkMGKh/wekHGAnAgggY2ExsIHdDACj9/2P4zQDyJyM4JwBl/jNB0xUDA7TdQX8PAAQQKAmBkgQ4KQPTNzDBMINJFkaG3/8ZIPkZmA2AUr8YGVggyR3iKyaQf4AqgIr//0dqStEXAAQQCzO4AgbFACOoQQFMP3/BuZIZkujBpQxQ/NcfcJ3AwPCLARoPwBhjA8fJP3CGgRRQ/8CNP3rmaYAAArWFQE1RSFvoHzTvAsP1P7i2+gWuof/+AZc3f0BuZQFrA3oH6L0/4Dj5/Q+kHpjk/sFcTc+oAAggUAyAwgzsDVABCvEDuFACJWsWUAoBJh5GcC3x8w/Ye+DwhjQ0fgEVM4OS0H9wrfcPVkvQzQ8AAcTCCK6ngBaDihFmcMECaUvDaihQo/ovuO0ALHBYQEXqf1ZQFAATD7CwYgO7FFIE/2WE1n0M/+iXigACiAVaUP4HB95/UHD+Y4QiRnAeYAR3aP6ASyq2P6Dc/B+UgBiYfoGK2t/g0okFnBlAdRy4imaEVdJ08ANAALEwgFs7jIxI3S5YmwIaA+AkDswAHKwMv0FFEgM7E9h9wArkNzgr/weJgyo4sF5om48BmulpDQACiAWSVv7/h6YZRGuZCdYf+AtG4JqL4T9UJdCxP5gZgEnp/2+wdiBihnZ6GMF6QemNLpEAEEAs8Pj+D04tjP8RXcd/4HzJAM4GoAYFONv+B7sM2BZiA1cULKzgvhtYFwsTtFUCa/XRoxMHEEAskIiG9FqgrUuwl6A++QfuUoLjAJj0QSHNAs4D4GYFsAoH+uQvCygqwCrAZTEzKK7+g+t1OjSTAAKIBVLg/Acnf0a4HxigZeI/RmhzjQHcYgV18JlB4Q3K0GCnAzWyMzD8ABZl4KT1GzLAwYQIfGYaj8oABBA0CSG6i0g9AUjOBqVmZmhJBRkmYodlFGDhA2yl/vrNwMIM8uff3wwcjAw/wPkeUrD+Z0DUbjQCAAHEAjGfESm7wUUY/8OGWMBJggncDQCCX8DsC25RszGDqmpmcPUMdCgrC7iVAU5gjJCewx+QLpr2PAECiAXUR2FEOJoBXpj+h5akTOAaAOQOcG3NBHYZELGA+0BAtwNNAFZhLOACCpT0IUXQf2hJ+g9WktEIAAQQqGkDiWUmePeXETouBGEz/kOqoZhANR1Qz39wkwjk4j8MrOBqAeh0YI4HOpSFEdqw/QsuACBtVdoBgABigbP+gctwiDf+wxIVqNQHByCkUmOCjUaAnMQMDvt/oJQDTP3M4L7BXxZokfAf1ij8By6+WCDtPxoAgABi+QcbvILk5n8MSDUavIBihHZioHUGM7T5xAIuhYAI2KRlBcuxgmX/g5vl/8HN1f/gJEq7NjZAALEALfsHG3hjgJdF/2ExAKsZoNUq2DWQXhgzuKhkBvf3WcADqP/AJSykq8kC7mr+BRfHwMzD+odWTVSAAGL5D+su/kNq//yHFaP/wa75jzxeDenugGPtP9iVbJB0Aq6b/4L9zAFumUOKJlBUgFMX839oiFDXGwABBEpCEDeBnP4fwfjPCBWH5If/sDiB1HEMkEF5JvAQ2H9QqQrKxEDP/AWpB/ZR2VkYfvwBZWgGcDxA6uz/f6k/2wAQQMwa0jBX/kepdOCdAQZYKmJEkmKEqWSE5fj/4GLqPzgq/oHD+R8T1JR/8HSI1NimFgAIIGZVaegEB8QP/5FapBARJibY+O5/mLsZYbkCph4RS/+hrZL/DNDaAAL+IUUgfBCfKgAggJjVpGGBDUv6cD7ElXARRqRuGgMjnIBW2P9h0zmISIC1SSHjraAakwVUWDMyQBtXVAEAAcSsLAEN3f+w0gZSeTIyIMIPxV+oaYkBVuBCcud/WBsOUhX++Q8VhGj/B44xuLepkqEBAgjkgX/wLux/RND+R3YfrKEK9QAjSgKAFE3/GFDSHoTLxIiIXki1yMAAbZL8/0+dhAQQQMwKotDK6D88+cLCBlIrMzLBoug/Us6G9eBgVTSI+AcZJ4UEMyxQIA2t/2Au0Ft/mRBVJBMDFVoZAAHELC8GouANuP+w/MfIiAgkeIfzH8wbjEitbgbkRhQDLLogev9BcwV8XJ4JyS64Mkp8ARBAzLIi0GwHifd/SMPlkIz47x+sVIG3t8Fzfkyw0RcGmBQjvBQC5wFmWOUASWCQnj5kWBKUwOCDN0jlARkAIICYZYSh9SiiPwlG//7Dql54xoWNMiBi4x+4SkYdEID7hAHWLYM4Dl5j/ofEA6QwZUIkTvLiASCAQFNM/yCjgv9ADGih8Q9WqDNAe7qI5ISUuRnBkyCQuhmSsqEJA1ZuQgFs0IkR3CxnYYSVtgzQkQRII5KBLD8ABBCzuACi9IAEDzxCoCS8gQTrnfyHRz0k5GBFJxOstIEkJIhPoE1RSM5mhJYTDAwwu5BqGMSoAikeAAggZlF+WOqHhxnYQX/BNkEaZ3//IeLhH7zAhZVaDOBeAWQQANk1iPYsrCj9C8lR4K4PE1JUMjLB2ouk52mAAGIW5gO12iGugQxQ/4VFAjRrMiAcCrGMkQGx7gCeN/4jFz7wjgSE/AfrVIB7Dn/ANfE/uMmw/AY1n0QPAAQQszAP2AV/wJNFsI7sf3BxAfUSAyxVMMA6PZC2ExNsMAZpLIwJuYnBAI0Q6EALJHbBtfJ/8KTEX3BNB2mcQqZAYS1gEvwAEEDMAlxgV4Id+pcBWp1B0gwDfBkOeHzqLyTNQGLgL8xL4PYCIzywYQB50h+RreEBDWmZwgY+GOBxjuR2Ir0BEEDMvFzQgIeEDQOspQUUhCQtyNwHIziXQKbyIfOwkMoV2lf8D0v0sLQEbRoywIZVYHUcvD75Dw51yITif1hYwFMgvFghCAACiJmPA2T6v7/Q9PDvHzSk/8BMhOTxv+AuG6icgddE/8AlI6zXCyu/oGx4w+kfaoqCFqmwdsr//6iZB6wO0iSB+xM/AAggZm52aBhDVENS0V+w+/7BGj//4Q0kRmgZ9R8e9kiNPwZYCcsE6/H8h4wGQNpKSBmUkQFavv3/j5ru/0GD/z+s1CYIAAKImZsDKQz+I/zACDPl9z9o+wyyAu0fA2ycHVID/IMOGSGCixHagIO3fBC1LyIiwIkKXmYgpZx/sLqA8T/CHDwAIICYudigJT20MmaAlnpQBHbffyZY8PyDLqdjgOUBBiTfMkNcAx6EZIQtY2MAMxiYoH6A+PMfI3S4Elq9gIUh+RASlH+R+kn4UxFAADFzsiFi8z+8eQgpUv9BK7j/sDzFCBNhYIT6BNJ2goxBMPyDDegywfpi4LEwRPqGFaaQEgyRRGGpFOTPv9BkCa8u8RdHAAHEDFpqAFP6D1a//oOvR4EFDnxoGtK9glgPV8YAXnPAAmlL/APXrLA+KiQ24C0FJqQiFeIuSP3zH1YcQ4fmIYMxkGIAbxQABBAzOwvMIJgT/8FyGAMjNE4gjYJ/sIzFCOvvM8DrVKQRDUbYhBUkFhBNCdRCCZ7xGGAxzwyu2hhgufEffAwBrwcAAoiZjQWa+v9DpjPgNS4sWhhg8+9Qf8KKcLg1DAzQ+o4Rlk0h0QWpv+BlKHz1EQNcBNaygqTev7BaAl5X/INZxMCI0xcAAcTMygwrUmAI4nT44g1GBkSehgO0zhQjLF0xQbqgTOBxPthSi/9MiCII2nZihLoewv4H7378RUpOsDobfyYACCBm+MAgA3KJDvcSstNhXoK2q5Ha3kywbMcIyzOQZZAQY+GlIaT+ggzFQpMZrLD/Byv6ECUKA3oLHKsvAAKImYUZlmbgo1qw4hw+RPUflmThgQEvKBhhehn/w4If1ltghHXzIa0MSO2GWAbACOVCyH+wNgtolcN/aBP1P6wNzwhLRZh+AAhAhRnlAACCIJRZ9z9y9QGIXcBNxYFvbQMFILJBT32Ij1aQ3IIsTeiBX6+JIkjbS5WZwxW0yrdrZnEIkq9QEmgFreFJGP4GngBiZmWBBSSsbEZ2MaJIholAmw//kEpD5CYkvBkDi33oSkiwQ5lhQ8VM/xH+/A8rA//DG7xg8jfM3QwMSB0GDA8ABBAoBhhhQY4sB2czYngDnk8YYB0XeIMUUhlB0jsksJlhkcDCBO2RMsCXlTNA4wSeVP7CaiGILdDiER4DSM1EOAAIIHAewOF0ZMAIM4IRVRm8OIcW/LCykuk/bNUybHU8dGiVCZqboQUrI0pJ+u8vtCUGSUL/Iauv4MUGtsFtgAACFaPwNA0rimDug80fo/kJHiHwSgqelSFlDsKJDNCF2f8hM+HwSoAJxTRohPyF1fGQtARuRCLCiAHafkHLygABBCuFkLMmcsCjuhu9YQgfwUZKaYyw8hS+kh+ysB/UlQOPI0GUMTMiFRUM0CYtZPXef1i5BHE01GOwKh8tBgACiBk6WYQSwgz4ASS8GeHeg5dUsLIS0oBjRBqgZwV7hpkRmtKYkQox6EAqZMwCnBn+Qsql/1BfQasIpLF+ZD8ABBAzC1Ko/ifC9WjeYIA32RkRYc8ISy3wnjFkgIgBMl7NBF3pDE+ikBWpDJA5NVh/ENLC/wfzFQOsVPyPGgkAAQStB1Dchb8HgexbRqgr4c0EaMsHPgQN5rNARuSZwKvJGWAegG1IYGSCdvAZYEn/DwN0MAaxauo/bDgDlifhnSiAAMLwAKo30IpORlQlCDbMJwywUS0mWIEDcSgzvMAFNzFAXR9wMmOB5EtIMoZXRP+gOfgfuFaGNDHho5HwXAxxG0AAoXgAM48SBMgRBh+BY/4P7btAl9wxQxMSxBvAXMcMixAG8EJmBkZokw46egDJsn/AbQomaMeQEWloEDmdAwQQwgNYXcvIiFRQ4vYdI5LroTU/TIQF7FB44mGGFUFMMB9Csg08O/3/j2gXQeqE32Dn/v2PmKFCHgkGCCBwc5oswIjGQOQAKAOSxJELU2YG6OYEUMnBDNsZBZuz+g9vVvwDDXoDI+QPbLgE3l9HbhFBPAAQQEyQJPufETlaMNyKtLEGDtDUw5uu0HIDqTn5F+Kgv+CUDR/A/AutB+Cx9x8+HgMbGGaCl7zgfjYksTHAR5PAPIAAYmZmhlVAMCeiTKeieoNghDDCXMACGyCCtHzgVTITEzRPQ9jQZjYs90OTEDjvQtLM77+w8dl/sEYHqr0AAcQET7sQkhEzbEkB8GbVX3hHAjbd/YcBmrj/wzaswQsTRlin9B/S0Dwj2J/MTLB2FBPUh5A2IjwwAQKIiQE5p8IyEwMs40LVwTyONQ7+YzL+Q8d2/sLHGMHkP1hehJY24OISVAf8heYWSCJhgkQXuI3DCIslBnAOZmGAzUrBDAUIIPiwN2wXHNxd8BSF6kD8CQnhDViH8y84Mfz5B20tQ5ufMFlI2EGGeCGdKgYmaHOQ+T/SkAxSC+IffPAY7A2AAGKCj6IxIgU8FoDX3egZGja3yQArQ6BhD5usB5bx/2EtHOjCgP+gxWnwihxSNDKBiywmWPuPASmx/GeA+hMggJgYYS2Z//BRVUKOxxoJcAcjDwLAC7d/SO1kUHZkgjV+GBAqGWFDqEz/YAn5H7R/xwQvEiBrLpBaCQABBM0a8GEfLG7D1X7AAeBKoAU20pgN1BP/YU2d/9DBFWjZBZsJZ4AFLSQDwBuLkBYuC6w9B0ldAAHEhBi4xAx+mFsQa3CIB7CGDZzNAPMJpJb9g7xghwHR2IK2Z5F6zEzweh2+ogfWwgUCgABigvfi/zMgUf/hzkBkSuTgx0xFyAEPLx/hCDFeBBt5hqTyf3BHg3stkI4BZMwCMrwO798xwZbA/YP1tiG2AAQQE6LVCatK/8NJPKGOIYUWddDQRQ6d/4gGGSgH/0VMbDAxIgxhhKdkRsS8IyO04obWBn/h4xQMDAABxIS1eiMbwM2BRzE8BiClJyPYEf9Q1TD8R5Qz0HqNATZQwAjtyzND2uRg41gYYJNaDAwAAQTqelDLD2gmwIp1WDAzIIZGGGG1739w0fkPFvnw4Wj4agtIaw/i4z+wqYO/sDoECAACCH3xF+FiBrdfUbIBXOQ/NNQZ/iMZDi80YLuhEGXgf9gKL2SnQCbamKAJmwk26QYEAAFExdVr6D6Bz2swwCpUyNw4E6zHg0g//xFFEHz0Cb6jixEWMxBfMTOhVPYAAcRCQgn5HysTi9uhDoOzYZ1mZgZovwy+sBbeWkYes0FMPjBAt5f/h9USkLlq+OwRUAQggFj+wzyH33X/CaUuRgx1yO1kaKzDxkkhCF6SMsOKKeTuLyRkIRO+UCnIKhSY6yEAIICQh8iwpG+U1EwcgLaHYXqhiwQZYV6AZGgmqAfgRQ3CARCnw9qq0EMUGBGyzEhHLQAFAAIIT5cep7vxNJbgtSojfNQE5iUm+L4usM2QVcnIxQ6iLvoHdTR83uk/rBHOCCuCoEHDwAAQQCxwi7Ema2KyB7Lr4YvTGCChzgwtRpmR2jaQ9gxkABhaGcEbAEiNpf+wFRl//iNKUnie/g/zBkAAsTAg5wFGvLUv0d6ALrqBVVvMTIjYYGKEhT0DLHP/hzr9H9LyM0g2gExUMyCleEgZ+hdp9ggggFBigAzXozRV4SUJrA3DDMu9kOBnYoJWorAsDW1+gqxlgjVRYaOikDFdRLEGa5UgKmmwRoAAYmLE5hRyXA93OvIpFbAmADO4n8UKbyczw/qK/2EZ4B9iZzhkMJSREZqP//yHeuYf0gA1AyzVAAQQYmz3P+6cgN/1jLCihgFWPkBCl5kROojLDB6NYwUnHhYm6LgvMwNiOQe8TQrPrP/B+8ahyzJgqR/iyr+MiNgAMgECiAnNQUTGAyM2DhMslUNGUCDOBQ0ksoAjgRHWcGCEji4ywdI0kgPBToTlY9BoEmxQkQmu6j9KXgUIIBbk+CAmBtCTDSy5MzAgJRsYyQJO9CyQLSuMoElLZvCeaxYG6FQ+fLKQATIP8Bc8CgYZg/kLdc8fcIT8hc1bwrwA9TJAALEwwedCYLkKuTbDWgHDkzu83GSEtb3gMcACKSvBLTDIABsLXAoyYPofurrlL6yK/Q+eE4CMYvz7B107Bl2qBFuICwn7f0h7fQECiAVedMBLNEbUqMBsYyK7ngHmB0jaYIUkeiZoSc8C3vAHjQdmaMphgTXxIbMVkOUiv8HNhj/g9AMZhIRYxwRpzMK4/zCWcQEEEAsjbPoW3itgROoZIYc61GOwvd+IIIdlWURgw9ggRzNCCyJWRmipygpxECM0Ff2FTIH9AYc3LNQhQ4u/wQwGWM8O7nTklRoAAZg4sxsAQBCGYqLuPzAesaWNfwxQrubB+y+0jtwvYWCmIY2+hVTrUaf95ZzJCm2UEY1T0YF4Qvrsyt2oJaaJRGvdBAlxEM43R5s7pKpnRrFJRtScA1cAqq0kCQAYgpnS/3+4dEGMnl0wkRiLMCbuCX2QQ790/eanTYOi2RzhNyXnBN+LY529cEWe9ze86SYCl28ok1FulhYqWC1RpHgRr9zXiV4g5QggFvg43l9Ub/xnROqRwJIWI8wUeNkPKXBYGGGzGOCShxVCgv3DCq6A2cC72CFlEfNfqCGQuIUMksJPBvqDNL8EOefi739oGw65aIGTAAGYOIMbAEAQBkbdf2Ilmngt6QY84AopoD9z14d32Yj3kDEbR1m1Q0BEqmCl8G/USAcQBKSt5Kgub/nROOwfOtkPc0543eWISbYRtfoEEAsbE9StkKUu8JqCCZYfkFvF8Dnq/7CKFlLyMDMhlTDgRA/atQtkgHMJM3gbHxMTomfIDEn64FQOSST/wAPAf2BbViDHe/0Fl05w18OjALnnAhCAaDNcASAEYTDX7d7/hU2Kb8zrlwQJitpcKaG9Vu7z0EEdsvLJyR/l5/nRfPcS7rdMrAvsoBSljx0n38sMxNWw80u4cXZhwMaeIlycD4Mapj2a+uN1BODSDFYAAEEYGur/f3BgRc5H0N3DhKmbGgHKhfHZUOhJRYhkpOEVfHuLtVbzsuqau1qRi/Qq6EbgbeqFe3GGyZJrM+vFhmQGTwZNIYzypxWOAGJhZ4L2ev79Q1TJQMexwkYH/jJAm42QY2EYYfmVAXKcGANoEyvLP9jkKVK2hhSszOBSn4ERevwPI3wSDZZTge4GOvfHHwQXsk/iNwO07P+H3N3BAAABuLgWHQBACDg9/v97S6NxVMsXeM3hRgPoyEEKvUODuNurxjYBUagUp9qx8naU7Z5h6DpLUquwgfzOWJPAg78tT5YpOjiIME7wwoOjmerqU3e+KgTZAoiFFbarH9qXg7VpEVNRTJAmB2LZD3QDFiPoRAkGBug4D2g1DbhlyAzvuDChDsVBghxcef0Bp41f4FD/CT7j5zc4Q/+BTUwxMCASGLS2QGpCILd0AAJQbSUoAIAgzLD+/9+KLNYm5QtkHpMNawPYDT4mtaQgYPb8EpjJWzd61K6Zdj2lFOTtWrhZ8XKNR0A3FompY15P3qcUE0Q21F3cS1LnI2X6/9C8sQUQCxt4+do/sJMhR5bBExwjbKURvBKAtC4ZYfNwDLAVZZAcwgwrJZiQIprxH7QO+g9eDvT7H9Qzf8BZ9udfaA0ASUL/GKCzaZA8idygxDVHARBALPBDLiErMRjgHTbYGPJ/WC8WYhIz0iwyfH0iK6zA+o/UyYLEHrxJDCki/4JTPFAZMNn8gtRfkMU1MB9C4gfe6oTvimHA7n4GgABigeyJYYapgzjoH7zeBVeYENczM8BqYgbowldGmDgkeCDDJH8hAQFvzUPKRAZo6P4BJ6Hf4HT/5x+iGIWkmb9/oX7+D2s+oIU7ph8AAogFXk9BaigGcGgxMcFqvn+wwUB4lwcW9kywmIUb+hc8PwcJbMgUGGQ64w/MD5CDD4Hh/fsvtJ76BRb/DduJ/x+p3kUeUMEa9hAAEECI43n+M0H3H8CDH9JSgPdH/zKBCvL/sAqOAdZtQF478psBeoDVfwYUD0CWnkASzF8MEjoJC19o8x8lB+Mf7AEIIBbIOl9GBtj2AEjc/YOWmP9hs+Sg1vJvxGToX7AP4dUkdPICklT+Q1vIf2F1yx9YOoGkH0hPBdF7ZID2g6EtAPiyJwaoaYgOIzYAEEAgD8CXcUOS03/YtAokI0Lc9w8e7PDNNLBSAj4rzAhbngJfxfoPdsDVP1iK/wtLWn8ZUF3/H9orgAQiSvmDLwIYAAII5AFgo+UXLJihKeQ/UkKCGPQPWshCXQyrnv7COrUMMP//gY2G/4Ula3iD+R/Scgmo3/5BEz106ybMJ2iJ5z9unwAEEAswA/39C6tfIQc7MUCnlP8zoKQuRtjMOyO8vGKEhjRyMwSSHRnAlRR8PgK6HecfNJvCXQ+dwf8HywBILiNY/kAAQACxAOtzRnCDhwm2ggK+RZYBNjkO2fsDaQ79RaqnEGUFBME3DcGqof/wFgGspfiXAbWBAFskgNnOIVj+QABAALH8+gtrY8JX0yK1ohnhfT+Y8fCl65DyCjqICQ9+sLo/MMf9hc0Nw2ulf/9Rsul/WL0LDwsG1DxAEAAEEMtf2IIFFiZoK4oRnoT+MyCKAEb0hsh/WDPpP3ytPyOSy1AdB0nfEJ/AWwoMSF0TeIMFudnDyEAYAAQQy09YL/P3f+jxU4zIBjFCAwe+h4IRPhwLCeZ/0PwALQRhWRleiv+FNRDhNdR/2Jri/wwoHkB2PQMR5Q8EAAQQy294wwZyoCtsNyMTpGT4i6jO4BU2JKEzYqwSQcxXMyBCmgE5nyAtHUB2OtxjDEgiRAKAAGL5DaspICSkMciMuoiREWm9CCOsqvoPG55gQCr4/qE5AlZAwRvq8LYW3Bv/MNxLZNhDAECAAQDQyZH7IItOogAAAABJRU5ErkJggg=="
	
const texture = new THREE.Texture();
texture.image = image;
image.onload = () => {
	texture.needsUpdate = true;
};


const shader = {
    defines: {
        ITERATIONS    : "20",
        OCTIVES       : "3"
    },
    uniforms: {
        flameTex      : { type : "t",     value : null },
        color         : { type : "c",     value : null },
        time          : { type : "f",     value : 0.0 },
        seed          : { type : "f",     value : 0.0 },
        invModelMatrix: { type : "m4",    value : null },
        scale         : { type : "v3",    value : null },
        noiseScale    : { type : "v4",    value : new THREE.Vector4(1, 2, 1, 0.3) },
        magnitude     : { type : "f",     value : 1.3 },
        lacunarity    : { type : "f",     value : 2.0 },
        gain          : { type : "f",     value : 0.5 }
    },

    vertexShader: `
        varying vec3 vWorldPos;
        void main() {
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            vWorldPos = (modelMatrix * vec4(position, 1.0)).xyz;
        }
		`,

    fragmentShader:	`
uniform vec3 color;
uniform float time;
uniform float seed;
uniform mat4 invModelMatrix;
uniform vec3 scale;
uniform vec4 noiseScale;
uniform float magnitude;
uniform float lacunarity;
uniform float gain;
uniform sampler2D flameTex;
varying vec3 vWorldPos;
vec3 mod289(vec3 x) {
return x - floor(x * (1.0 / 289.0)) * 289.0;
}
vec4 mod289(vec4 x) {
return x - floor(x * (1.0 / 289.0)) * 289.0;
}
vec4 permute(vec4 x) {
return mod289(((x * 34.0) + 1.0) * x);
}
vec4 taylorInvSqrt(vec4 r) {
return 1.79284291400159 - 0.85373472095314 * r;
}
float snoise(vec3 v) {
const vec2 C = vec2(1.0 / 6.0, 1.0 / 3.0);
const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
vec3 i  = floor(v + dot(v, C.yyy));
vec3 x0 = v - i + dot(i, C.xxx);
vec3 g = step(x0.yzx, x0.xyz);
vec3 l = 1.0 - g;
vec3 i1 = min(g.xyz, l.zxy);
vec3 i2 = max(g.xyz, l.zxy);
vec3 x1 = x0 - i1 + C.xxx;
vec3 x2 = x0 - i2 + C.yyy;
vec3 x3 = x0 - D.yyy;
i = mod289(i); 
vec4 p = permute(permute(permute( 
i.z + vec4(0.0, i1.z, i2.z, 1.0))
+ i.y + vec4(0.0, i1.y, i2.y, 1.0)) 
+ i.x + vec4(0.0, i1.x, i2.x, 1.0));
float n_ = 0.142857142857;
vec3  ns = n_ * D.wyz - D.xzx;
vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
vec4 x_ = floor(j * ns.z);
vec4 y_ = floor(j - 7.0 * x_);
vec4 x = x_ * ns.x + ns.yyyy;
vec4 y = y_ * ns.x + ns.yyyy;
vec4 h = 1.0 - abs(x) - abs(y);
vec4 b0 = vec4(x.xy, y.xy);
vec4 b1 = vec4(x.zw, y.zw);
vec4 s0 = floor(b0) * 2.0 + 1.0;
vec4 s1 = floor(b1) * 2.0 + 1.0;
vec4 sh = -step(h, vec4(0.0));
vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy;
vec4 a1 = b1.xzyw + s1.xzyw * sh.zzww;
vec3 p0 = vec3(a0.xy, h.x);
vec3 p1 = vec3(a0.zw, h.y);
vec3 p2 = vec3(a1.xy, h.z);
vec3 p3 = vec3(a1.zw, h.w);
vec4 norm = taylorInvSqrt(vec4(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3)));
p0 *= norm.x;
p1 *= norm.y;
p2 *= norm.z;
p3 *= norm.w;
vec4 m = max(0.6 - vec4(dot(x0, x0), dot(x1, x1), dot(x2, x2), dot(x3, x3)), 0.0);
m = m * m;
return 42.0 * dot(m * m, vec4(dot(p0, x0), dot(p1, x1), dot(p2, x2), dot(p3, x3)));
}
float turbulence(vec3 p) {
float sum = 0.0;
float freq = 1.0;
float amp = 1.0;
for(int i = 0; i < OCTIVES; i++) {
sum += abs(snoise(p * freq)) * amp;
freq *= lacunarity;
amp *= gain;
}
return sum;
}
vec4 samplerFlame (vec3 p, vec4 scale) {
vec2 st = vec2(sqrt(dot(p.xz, p.xz)), p.y);
if(st.x <= 0.0 || st.x >= 1.0 || st.y <= 0.0 || st.y >= 1.0) return vec4(0.0);
p.y -= (seed + time) * scale.w;
p *= scale.xyz;
st.y += sqrt(st.y) * magnitude * turbulence(p);
if(st.y <= 0.0 || st.y >= 1.0) return vec4(0.0);
return texture2D(flameTex, st);
}
vec3 localize(vec3 p) {
return (invModelMatrix * vec4(p, 1.0)).xyz;
}
void main() {
vec3 rayPos = vWorldPos;
vec3 rayDir = normalize(rayPos - cameraPosition);
float rayLen = 0.0288 * length(scale.xyz);
vec4 col = vec4(0.0);
for(int i = 0; i < ITERATIONS; i++) {
rayPos += rayDir * rayLen;
vec3 lp = localize(rayPos);
lp.y += 0.5;
lp.xz *= 2.0;
col += samplerFlame(lp, noiseScale);
}
col.a = col.r;
gl_FragColor = col;
}
`
	}
class Flame extends THREE.Mesh {
	
	constructor(flameTex, color) {
	const flameMaterial = new THREE.ShaderMaterial( {
        defines         : shader.defines,
        uniforms        : THREE.UniformsUtils.clone( shader.uniforms ),
        vertexShader    : shader.vertexShader,
        fragmentShader  : shader.fragmentShader,
		transparent     : true,
		depthWrite      : false,
        depthTest       : false
	} );

    // initialize uniforms 

    flameTex.magFilter = flameTex.minFilter = THREE.LinearFilter;
    flameTex.wrapS = THREE.wrapT = THREE.ClampToEdgeWrapping;
    
    flameMaterial.uniforms.flameTex.value = flameTex;
    flameMaterial.uniforms.color.value = color || new THREE.Color( 0xeeeeee );
    flameMaterial.uniforms.invModelMatrix.value = new THREE.Matrix4();
    flameMaterial.uniforms.scale.value = new THREE.Vector3( 1, 1, 1 );
    flameMaterial.uniforms.seed.value = Math.random() * 19.19;

		super( new THREE.BoxGeometry( 1.0, 1.0, 1.0 ), flameMaterial);
	}
	
	update(time) {
		
    const invModelMatrix = this.material.uniforms.invModelMatrix.value;

    this.updateMatrix();
    invModelMatrix.getInverse( this.matrix );

    if( time !== undefined ) {
        this.material.uniforms.time.value = time;
    }

    this.material.uniforms.invModelMatrix.value = invModelMatrix;

    this.material.uniforms.scale.value = this.scale;

	}
}


const bootstrapThree = ({width, height, render}) => {
	
// ---- bootstrapping-code
const renderer = new THREE.WebGLRenderer({
  alpha: true, 
  antialias: true
});
renderer.setSize(width, height);

const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(
    60, width / height, 0.1, 5000);
const controls = new THREE.OrbitControls(camera);
camera.position.set(100, 0, -100);
camera.lookAt(new THREE.Vector3(0, 0, 0));

requestAnimationFrame(function loop(time) {
  controls.update();

	render(time);
  renderer.render(scene, camera);
  requestAnimationFrame(loop);
});

window.addEventListener('resize', () => {
	const {innerWidth: width, innerHeight: height} = window;
  renderer.setSize(width, height);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
});


	return {
		renderer,
		scene,
		camera
	}
}


const speed = 0.002;

const {innerWidth: width, innerHeight: height} = window;
const {
	renderer,
	scene
} = bootstrapThree({
	width, 
	height,
	render: time => {
			if (flame) {
		flame.update(time * speed);
	}
	}
});
document.body.appendChild(renderer.domElement);

flame = new Flame( texture );
const scale = 100;
flame.scale.set(scale, scale, scale);
scene.add( flame );