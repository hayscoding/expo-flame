A Pen created at CodePen.io. You can find this one at https://codepen.io/EvanBacon/pen/LzGpda.

 A Fire / Flame Shader in THREE.js, WebGL